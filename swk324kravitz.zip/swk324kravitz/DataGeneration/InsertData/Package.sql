insert into Package (pkgID, package_name, price) values (1, 'Tow Package', 120000);
insert into Package (pkgID, package_name, price) values (2, 'Luxury Package', 28000);
insert into Package (pkgID, package_name, price) values (3, 'Security Package', 190000);
insert into Package (pkgID, package_name, price) values (4, 'Racing Package', 178000);
