update Vehicle
set sID = 1
where sID = 9617 and cID is NULL;
update Vehicle
set sID = 608
where sID = 1 and cID is NULL;

update Vehicle
set sID = 2
where sID = 2526 and cID is NULL;
update Vehicle
set sID = 7634
where sID = 2 and cID is NULL;

update Vehicle
set sID = 3
where sID = 9886 and cID is NULL;
update Vehicle
set sID = 7670
where sID = 3 and cID is NULL;

update Vehicle
set sID = 4
where sID = 6821 and cID is NULL;
update Vehicle
set sID = 3254
where sID = 4 and cID is NULL;

update Vehicle
set sID = 5
where sID = 608 and cID is NULL;
update Vehicle
set sID = 7591
where sID = 5 and cID is NULL;

update Vehicle
set sID = 6
where sID = 7634 and cID is NULL;
update Vehicle
set sID = 4393
where sID = 6 and cID is NULL;

update Vehicle
set sID = 7
where sID = 7670 and cID is NULL;
update Vehicle
set sID = 3012
where sID = 7 and cID is NULL;

update Vehicle
set sID = 8
where sID = 3254 and cID is NULL;
update Vehicle
set sID = 5497
where sID = 8 and cID is NULL;

update Vehicle
set sID = 9
where sID = 7591 and cID is NULL;
update Vehicle
set sID = 9617
where sID = 9 and cID is NULL;

update Vehicle
set sID = 10
where sID = 4393 and cID is NULL;
update Vehicle
set sID = 2526
where sID = 10 and cID is NULL;

update Vehicle
set sID = 11
where sID = 3012 and cID is NULL;
update Vehicle
set sID = 9886
where sID = 11 and cID is NULL;

update Vehicle
set sID = 12
where sID = 5497 and cID is NULL;
update Vehicle
set sID = 6821
where sID = 12 and cID is NULL;